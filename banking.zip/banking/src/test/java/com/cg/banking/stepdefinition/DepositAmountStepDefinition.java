package com.cg.banking.stepdefinition;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.banking.pagebeans.DepositAmountPage;
import com.cg.banking.pagebeans.IndexPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class DepositAmountStepDefinition {
	
	private WebDriver driver=new ChromeDriver();
	private IndexPage indexPage;
	private DepositAmountPage depositAmountPage;
	
	@Given("^User is on Capgemini Banking Portal 'indexPage'$")
	public void user_is_on_Capgemini_Banking_Portal_indexPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver.get("http://localhost:7898/home");
		String actualTitle=driver.getTitle();
		String expectedTitle="Capgemini";
		Assert.assertEquals(expectedTitle, actualTitle);
		indexPage=PageFactory.initElements(driver, IndexPage.class);
	}

	@When("^User clicks on 'Deposit' button$")
	public void user_clicks_on_Deposit_button() throws Throwable {
		indexPage.clickDepositAmountButton();
	}

	@Then("^User is navigated to 'getDepositAmountPage'$")
	public void user_is_navigated_to_getDepositAmountPage() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Get Deposit Details";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@Given("^User is on the 'getDepositAmountPage'$")
	public void user_is_on_the_getDepositAmountPage() throws Throwable {
		driver.get("http://localhost:7898/depositAmount");
		String actualTitle=driver.getTitle();
		String expectedTitle="Get Deposit Details";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@When("^User Enters Invalid Account Number$")
	public void user_Enters_Invalid_Account_Number() throws Throwable {
		depositAmountPage=PageFactory.initElements(driver, DepositAmountPage.class);
		depositAmountPage.setAccountNumber("1234");
		depositAmountPage.setAccountBalance("4500");
		depositAmountPage.clickSubmit();
	}

	@Then("^Error Message regarding Invalid Account Number displayed on 'getDepositAmountPage'$")
	public void error_Message_regarding_Invalid_Account_Number_displayed_on_getDepositAmountPage() throws Throwable {
		String actualMessage=depositAmountPage.getActualMessage();
		String expectedMessage="Account Number is Not Found!!!!! Please Enter Right Account Number";
		Assert.assertEquals(expectedMessage, actualMessage);
	}
	
	@When("^User Enters Invalid Amount$")
	public void user_Enters_Invalid_Amount() throws Throwable {
		depositAmountPage=PageFactory.initElements(driver, DepositAmountPage.class);
		depositAmountPage.setAccountNumber("1");
		depositAmountPage.setAccountBalance("-4500");
		depositAmountPage.clickSubmit();
	}
		
	@Then("^Error Message regarding Invalid Amount  displayed on 'getDepositAmountPage'$")
	public void error_Message_regarding_Invalid_Amount_displayed_on_getDepositAmountPage() throws Throwable {
		String actualMessage=depositAmountPage.getActualMessage();
		String expectedMessage="Amount is Not Valid!!!!! Please Enter Valid Amount";
		Assert.assertEquals(expectedMessage, actualMessage);
	}
	@When("^User Enters valid Data$")
	public void user_Enters_valid_Data() throws Throwable {
		depositAmountPage=PageFactory.initElements(driver, DepositAmountPage.class);
		depositAmountPage.setAccountNumber("1");
		depositAmountPage.setAccountBalance("4500");
		depositAmountPage.clickSubmit();
	}

	@Then("^User is navigated to 'indexPage' to display his updated Amount$")
	public void user_is_navigated_to_indexPage_to_display_his_updated_Amount() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Capgemini";
		Assert.assertEquals(expectedTitle, actualTitle);
	}
}
