package com.cg.banking.stepdefinition;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.banking.pagebeans.IndexPage;
import com.cg.banking.pagebeans.RegisterPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class OpenAccountStepDefinition {
	private WebDriver driver=new ChromeDriver();
	private IndexPage indexPage;
	private RegisterPage registerPage;
	@Given("^User is on the Capgemini Banking Portal 'indexPage'$")
	public void user_is_on_the_Capgemini_Banking_Portal_indexPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver.get("http://localhost:7898/home");
		String actualTitle=driver.getTitle();
		String expectedTitle="Capgemini";
		Assert.assertEquals(expectedTitle, actualTitle);
		indexPage=PageFactory.initElements(driver, IndexPage.class);
	}

	@When("^User clicks on 'openAccount' button$")
	public void user_clicks_on_openAccount_button() throws Throwable {
		indexPage.clickregisterButton();
	}

	@Then("^User is navigated to 'registerPage'$")
	public void user_is_navigated_to_registerPage() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Registration";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@Given("^User is on 'registerPage'$")
	public void user_is_on_registerPage() throws Throwable {
		driver.get("http://localhost:7898/register");
		String actualTitle=driver.getTitle();
		String expectedTitle="Registration";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@When("^User Enters Invalid Registration details$")
	public void user_Enters_Invalid_Registration_details() throws Throwable {
		registerPage=PageFactory.initElements(driver, RegisterPage.class);
		registerPage.setCustomerName("Ashav Kumar");
		registerPage.setAddress("Agra");
		registerPage.setEmailId("ashav21011996gmail.com");
		registerPage.setPancard("HHTPK0434B");
		registerPage.setAccountType("Saving");
		registerPage.setAccountBalance("41143");
		registerPage.setSecurityQuestion("0");
		registerPage.setSecretAnswer("Capgemini");
		registerPage.clickSubmit();
	}

	@Then("^Error Message displayed on 'registerPage'$")
	public void error_Message_displayed_on_registerPage() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Registration";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@Given("^User is on the 'registerPage'$")
	public void user_is_on_the_registerPage() throws Throwable {
		driver.get("http://localhost:7898/register");
		String actualTitle=driver.getTitle();
		String expectedTitle="Registration";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@When("^User Enters valid set of Registration details$")
	public void user_Enters_valid_set_of_Registration_details() throws Throwable {
		registerPage=PageFactory.initElements(driver, RegisterPage.class);
		registerPage.setCustomerName("Ashav Kumar");
		registerPage.setAddress("Agra");
		registerPage.setEmailId("ashav21011996@gmail.com");
		registerPage.setPancard("HHTPK0434B");
		registerPage.setAccountType("Saving");
		registerPage.setAccountBalance("41143");
		registerPage.setSecurityQuestion("Which website you rarely visit?");
		registerPage.setSecretAnswer("Capgemini");
		registerPage.clickSubmit();
	}

	@Then("^User is navigated to 'registerSuccessPage' to display his Account Number$")
	public void user_is_navigated_to_registerSuccessPage_to_display_his_Account_Number() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Registration Success";
		Assert.assertEquals(expectedTitle, actualTitle);
	}
}
