package com.cg.banking.stepdefinition;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.banking.pagebeans.FundTransferPage;
import com.cg.banking.pagebeans.IndexPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class FundTransferStepDefinition {
		
	private WebDriver driver=new ChromeDriver();
	private IndexPage indexPage;
	private FundTransferPage fundTransferPage;
	@Given("^User is on Capgemini Banking Portal System$")
	public void user_is_on_Capgemini_Banking_Portal_System() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver.get("http://localhost:7898/home");
		String actualTitle=driver.getTitle();
		String expectedTitle="Capgemini";
		Assert.assertEquals(expectedTitle, actualTitle);
		indexPage=PageFactory.initElements(driver, IndexPage.class);
	}
	
	@When("^User clicks on 'fundTransfer' button$")
	public void user_clicks_on_fundTransfer_button() throws Throwable {
		indexPage.clickFundTransferButton();
	}

	@Then("^User is navigated to 'getFundTransferDetailsPage'$")
	public void user_is_navigated_to_getFundTransferDetailsPage() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Get FundTransfer Details";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@Given("^User is on the 'getFundTransferDetailsPage'$")
	public void user_is_on_the_getFundTransferDetailsPage() throws Throwable {
		driver.get("http://localhost:7898/fundTransfer");
		String actualTitle=driver.getTitle();
		String expectedTitle="Get FundTransfer Details";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@When("^User Enters Invalid From_Account Number$")
	public void user_Enters_Invalid_From_Account_Number() throws Throwable {
		fundTransferPage=PageFactory.initElements(driver, FundTransferPage.class);
		fundTransferPage.setAccountNoFrom("1234");
		fundTransferPage.setAccountNoTo("2");
		fundTransferPage.setTransferAmount("4500");
		fundTransferPage.clickSubmit();
	}

	@Then("^Error Message regarding Invalid From_Account Number displayed on 'getFundTransferDetailsPage'$")
	public void error_Message_regarding_Invalid_From_Account_Number_displayed_on_getFundTransferDetailsPage() throws Throwable {
		String actualMessage=fundTransferPage.getActualMessage();
		String expectedMessage="Account Number is Not Found!!!!! Please Enter Right Account Number";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User Enters Invalid To_Account Number$")
	public void user_Enters_Invalid_To_Account_Number() throws Throwable {
		fundTransferPage=PageFactory.initElements(driver, FundTransferPage.class);
		fundTransferPage.setAccountNoFrom("1");
		fundTransferPage.setAccountNoTo("1234");
		fundTransferPage.setTransferAmount("4500");
		fundTransferPage.clickSubmit();
	}

	@Then("^Error Message regarding Invalid To_Account Number displayed on 'getFundTransferDetailsPage'$")
	public void error_Message_regarding_Invalid_To_Account_Number_displayed_on_getFundTransferDetailsPage() throws Throwable {
		String actualMessage=fundTransferPage.getActualMessage();
		String expectedMessage="Account Number is Not Found!!!!! Please Enter Right Account Number";
		Assert.assertEquals(expectedMessage, actualMessage);
	}
	
	@When("^User Enter the Amount$")
	public void user_Enter_the_Amount() throws Throwable {
		fundTransferPage=PageFactory.initElements(driver, FundTransferPage.class);
		fundTransferPage.setAccountNoFrom("1");
		fundTransferPage.setAccountNoTo("2");
		fundTransferPage.setTransferAmount("45000");
		fundTransferPage.clickSubmit();
	}

	@Then("^Error Message regarding Insufficient Amount  displayed on 'getFundTransferDetailsPage'$")
	public void error_Message_regarding_Insufficient_Amount_displayed_on_getFundTransferDetailsPage() throws Throwable {
		String actualMessage=fundTransferPage.getActualMessage();
		String expectedMessage="Insufficient Amount!!!Please Make another Transaction.";
		Assert.assertEquals(expectedMessage, actualMessage);
	}
	
	@When("^User Enter the Invalid Amount$")
	public void user_Enter_the_Invalid_Amount() throws Throwable {
		fundTransferPage=PageFactory.initElements(driver,FundTransferPage.class);
		fundTransferPage.setAccountNoFrom("1");
		fundTransferPage.setAccountNoTo("2");
		fundTransferPage.setTransferAmount("-4500");
		fundTransferPage.clickSubmit();
	}

	@Then("^Error Message regarding Invalid Amount  displayed on 'getFundTransferDetailsPage'$")
	public void error_Message_regarding_Invalid_Amount_displayed_on_getFundTransferDetailsPage() throws Throwable {
		String actualMessage=fundTransferPage.getActualMessage();
		String expectedMessage="Amount is Not Valid!!!!! Please Enter Valid Amount";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User Enter set of valid Data$")
	public void user_Enter_set_of_valid_Data() throws Throwable {
		fundTransferPage=PageFactory.initElements(driver,FundTransferPage.class);
		fundTransferPage.setAccountNoFrom("1");
		fundTransferPage.setAccountNoTo("2");
		fundTransferPage.setTransferAmount("4500");
		fundTransferPage.clickSubmit();
	}

	@Then("^User is navigated to 'indexPage' to display updated Amount on indexPage$")
	public void user_is_navigated_to_indexPage_to_display_updated_Amount_on_indexPage() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Capgemini";
		Assert.assertEquals(expectedTitle, actualTitle);
	}
}
