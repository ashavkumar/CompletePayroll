package com.cg.banking.stepdefinition;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.banking.pagebeans.AccountNoPage;
import com.cg.banking.pagebeans.IndexPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class AccountStatementStepDefinition {
	WebDriver driver=new ChromeDriver();
	IndexPage indexPage;
	AccountNoPage accountNoPage;
	
	@Given("^Customer is on the 'Capgemini Banking System' Portal$")
	public void customer_is_on_the_Capgemini_Banking_System_Portal() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver.get("http://localhost:7898/home");
		String actualTitle=driver.getTitle();
		String expectedTitle="Capgemini";
		Assert.assertEquals(expectedTitle, actualTitle);
		indexPage=PageFactory.initElements(driver, IndexPage.class);
	}
	
	@When("^Customer clicks on 'Account Statement' button$")
	public void customer_clicks_on_Account_Statement_button() throws Throwable {
		indexPage.clickAccountAllTransactionsButton();
	}

	@Then("^Customer is navigated to 'getAccountNoPage'$")
	public void customer_is_navigated_to_getAccountNoPage() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Account No";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@Given("^Customer is on 'getAccountNoPage'$")
	public void customer_is_on_getAccountNoPage() throws Throwable {
		driver.get("http://localhost:7898/accountAllTransactions");
		String actualTitle=driver.getTitle();
		String expectedTitle="Account No";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@When("^Customer enters his Invalid 'AccountNo'$")
	public void customer_enters_his_Invalid_AccountNo() throws Throwable {
		accountNoPage=PageFactory.initElements(driver, AccountNoPage.class);
		accountNoPage.setaccountNo("12");
		accountNoPage.clickSubmit();
	}

	@Then("^Displayed 'Error message' on 'getAccountNoPage'$")
	public void displayed_Error_message_on_getAccountNoPage() throws Throwable {
		String actualMessage=accountNoPage.getActualErrorMessage();
		String expectedMessage="Account Number is Not Found!!!!! Please Enter Right Account Number";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@Given("^Customer is on the 'getAccountNoPage'$")
	public void customer_is_on_the_getAccountNoPage() throws Throwable {
		driver.get("http://localhost:7898/accountAllTransactions");
		String actualTitle=driver.getTitle();
		String expectedTitle="Account No";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@When("^Customer enters his valid 'AccountNo'$")
	public void customer_enters_his_valid_AccountNo() throws Throwable {
		accountNoPage=PageFactory.initElements(driver, AccountNoPage.class);
		accountNoPage.setaccountNo("1");
		accountNoPage.clickSubmit();
		}

	@Then("^Customer is navigated to 'displayAccountStatementPage' to display his Account Statement$")
	public void customer_is_navigated_to_displayAccountStatementPage_to_display_his_Account_Statement() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Transaction Details";
		Assert.assertEquals(expectedTitle, actualTitle);
	}
}
