package com.cg.banking.stepdefinition;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.banking.pagebeans.IndexPage;
import com.cg.banking.pagebeans.WithdrawAmountPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class WithdrawAmountStepDefinition {
	private WebDriver driver=new ChromeDriver();
	private IndexPage indexPage;
	private WithdrawAmountPage withdrawAmountPage;
	@Given("^User is on Capgemini Banking Portal$")
	public void user_is_on_Capgemini_Banking_Portal() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver.get("http://localhost:7898/home");
		String actualTitle=driver.getTitle();
		String expectedTitle="Capgemini";
		Assert.assertEquals(expectedTitle, actualTitle);
		indexPage=PageFactory.initElements(driver, IndexPage.class);
	}

	@When("^User clicks on 'Withdraw' button$")
	public void user_clicks_on_Withdraw_button() throws Throwable {
		indexPage.clickWithdrawAmountButton();
	}

	@Then("^User is navigated to 'getWithdrawAmountPage'$")
	public void user_is_navigated_to_getWithdrawAmountPage() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Get Withdrawal Details";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@Given("^User is on the 'getWithdrawAmountPage'$")
	public void user_is_on_the_getWithdrawAmountPage() throws Throwable {
		driver.get("http://localhost:7898/withdrawAmount");
		String actualTitle=driver.getTitle();
		String expectedTitle="Get Withdrawal Details";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@When("^User Enters his Invalid Account Number$")
	public void user_Enters_his_Invalid_Account_Number() throws Throwable {
		withdrawAmountPage=PageFactory.initElements(driver, WithdrawAmountPage.class);
		withdrawAmountPage.setAccountNumber("1234");
		withdrawAmountPage.setAccountBalance("4500");
		withdrawAmountPage.clickSubmit();
	}

	@Then("^Error Message regarding Invalid Account Number displayed on 'getWithdrawAmountPage'$")
	public void error_Message_regarding_Invalid_Account_Number_displayed_on_getWithdrawAmountPage() throws Throwable {
		String actualMessage=withdrawAmountPage.getActualMessage();
		String expectedMessage="Account Number is Not Found!!!!! Please Enter Right Account Number";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User Enter Invalid Amount$")
	public void user_Enter_Invalid_Amount() throws Throwable {
		withdrawAmountPage=PageFactory.initElements(driver, WithdrawAmountPage.class);
		withdrawAmountPage.setAccountNumber("1");
		withdrawAmountPage.setAccountBalance("-4500");
		withdrawAmountPage.clickSubmit();
	}

	@Then("^Error Message regarding Invalid Amount  displayed on 'getWithdrawAmountPage'$")
	public void error_Message_regarding_Invalid_Amount_displayed_on_getWithdrawAmountPage() throws Throwable {
		String actualMessage=withdrawAmountPage.getActualMessage();
		String expectedMessage="Amount is Not Valid!!!!! Please Enter Valid Amount";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^User Enters set of valid Data$")
	public void user_Enters_set_of_valid_Data() throws Throwable {
		withdrawAmountPage=PageFactory.initElements(driver,WithdrawAmountPage.class);
		withdrawAmountPage.setAccountNumber("1");
		withdrawAmountPage.setAccountBalance("4500");
		withdrawAmountPage.clickSubmit();
	}

	@Then("^User is navigated to 'indexPage' to display updated Amount$")
	public void user_is_navigated_to_indexPage_to_display_updated_Amount() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Capgemini";
		Assert.assertEquals(expectedTitle, actualTitle);
	}
}
