package com.cg.banking.pagebeans;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
public class CustomerIdPage {
	@FindBy(how=How.NAME,name="customerId")
	private WebElement customerId;
	
	@FindBy(how=How.NAME,name="submit")
	private WebElement button;
	
	@FindBy(how=How.CLASS_NAME,className="errorMessage")
	private WebElement actualErrorMessage;
	
	public CustomerIdPage() {
		super();
	}
	
	public String getCustomerId() {
		return customerId.getAttribute("value");
	}
	public void setCustomerId(String customerId) {
		
		this.customerId.sendKeys(customerId);
	}
	
	public String getActualErrorMessage(){
		return actualErrorMessage.getText();
	}

	public void clickSubmit() {
		button.click();
	}
}
