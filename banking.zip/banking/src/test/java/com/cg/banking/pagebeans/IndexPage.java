package com.cg.banking.pagebeans;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
public class IndexPage {
	@FindBy(how=How.NAME,name="register")
	private WebElement registerButton;
	
	@FindBy(how=How.NAME,name="depositAmount")
	private WebElement depositAmountButton;
	
	@FindBy(how=How.NAME,name="withdrawAmount")
	private WebElement withdrawAmountButton;
	
	@FindBy(how=How.NAME,name="fundTransfer")
	private WebElement fundTransferButton;

	@FindBy(how=How.NAME,name="customerDetails")
	private WebElement customerDetailsButton;
	
	@FindBy(how=How.NAME,name="accountAllTransactions")
	private WebElement accountAllTransactionsButton;
	
	@FindBy(how=How.NAME,name="allAccountDetails")
	private WebElement allAccountDetailsButton;
	
	@FindBy(how=How.NAME,name="allCustomerDetails")
	private WebElement allCustomerDetailsButton;
	
	@FindBy(how=How.NAME,name="allTransactionDetails")
	private WebElement allTransactionDetailsButton;
	
	@FindBy(how=How.CLASS_NAME,className="message")
	private WebElement actualMessage;
	
	public IndexPage() {
		super();
	}
	public void clickregisterButton() {
		registerButton.click();
	}
	public void clickDepositAmountButton() {
		depositAmountButton.click();
	}
	public void clickWithdrawAmountButton() {
		withdrawAmountButton.click();
	}
	public void clickFundTransferButton() {
		fundTransferButton.click();
	}	
	public void clickCustomerDetailsButton() {
		customerDetailsButton.click();
	}	
	public void clickAccountAllTransactionsButton() {
		accountAllTransactionsButton.click();
	}	
	public void clickAllAccountDetailsButton() {
		allAccountDetailsButton.click();
	}
	public void clickAllCustomerDetailsButton() {
		allCustomerDetailsButton.click();
	}
	public void clickAllTransactionDetailsButton() {
		allTransactionDetailsButton.click();
	}
	public String getActualMessage(){
		return actualMessage.getText();
	}
}
