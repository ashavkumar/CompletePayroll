package com.cg.banking.pagebeans;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
public class FundTransferPage{
	
	@FindBy(how=How.NAME,name="accountNoFrom")
	private WebElement accountNoFrom;
	
	@FindBy(how=How.NAME,name="accountNoTo")
	private WebElement accountNoTo;
	
	@FindBy(how=How.NAME,name="transferAmount")
	private WebElement transferAmount;

	
	@FindBy(how=How.NAME,name="submit")
	private WebElement button;
	
	@FindBy(how=How.CLASS_NAME,className="errorMessage")
	private WebElement actualMessage;

	public FundTransferPage() {
		super();
	}

	public String getAccountNoFrom() {
		return accountNoFrom.getAttribute("value");
	}

	public void setAccountNoFrom(String accountNoFrom) {
		this.accountNoFrom.clear();
		this.accountNoFrom.sendKeys(accountNoFrom);
	}

	public String getAccountNoTo() {
		return accountNoTo.getAttribute("value");
	}

	public void setAccountNoTo(String accountNoTo) {
		this.accountNoTo.clear();
		this.accountNoTo.sendKeys(accountNoTo);
	}
	
	public String getTransferAmount() {
		return transferAmount.getAttribute("value");
	}

	public void setTransferAmount(String transferAmount) {
		this.transferAmount.clear();
		this.transferAmount.sendKeys(transferAmount);
	}
	
	public String getActualMessage(){
		return actualMessage.getText();
	}
	
	public void clickSubmit() {
		button.click();
	}
}
