package com.cg.banking.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.banking.pagebeans.IndexPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AllCustomerDetailsStepDefinition {

	private WebDriver driver=new ChromeDriver();
	private IndexPage indexPage;
	

	@Given("^Admin is on the Portal 'Capgemini Banking System'$")
	public void admin_is_on_the_Portal_Capgemini_Banking_System() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver.get("http://localhost:7898/home");
		String actualTitle=driver.getTitle();
		String expectedTitle="Capgemini";
		Assert.assertEquals(expectedTitle, actualTitle);
		indexPage=PageFactory.initElements(driver, IndexPage.class);
	}

	@When("^Admin clicks on 'All Customer Details' button$")
	public void admin_clicks_on_All_Customer_Details_button() throws Throwable {
		indexPage.clickAllCustomerDetailsButton();
	}

	@Then("^Admin is navigated to 'displayAllCustomerDetailsPage'$")
	public void admin_is_navigated_to_displayAllCustomerDetailsPage() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="All Customer Details";
		Assert.assertEquals(expectedTitle, actualTitle);
	}
}
