package com.cg.banking.pagebeans;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
public class RegisterPage {
	@FindBy(how=How.ID,id="customerName")
	private WebElement customerName;
	
	@FindBy(how=How.ID,id="address")
	private WebElement address;

	@FindBy(how=How.ID,id="emailId")
	private WebElement emailId;

	@FindBy(how=How.ID,id="pancard")
	private WebElement pancard;

	@FindBy(how=How.NAME,name="accounts[0].accountBalance")
	private WebElement accountBalance;

	@FindBy(how=How.NAME,name="accounts[0].accountType")
	private WebElement accountType;

	@FindBy(how=How.ID,id="securityQuestion")
	private WebElement securityQuestion;
	
	//Select select =new Select(securityQuestion);
	
	@FindBy(how=How.ID,id="user.secretQuestion")
	private WebElement secretAnswer;

	@FindBy(how=How.NAME,name="submit")
	private WebElement button;
	
	public RegisterPage() {
		super();
	}

	public String getCustomerName() {
		return customerName.getAttribute("value");
	}

	public void setCustomerName(String customerName) {
		this.customerName.sendKeys(customerName);
	}

	public String getAddress() {
		return address.getAttribute("value");
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}
	public String getEmailId() {
		return emailId.getAttribute("value");
	}

	public void setEmailId(String emailId) {
		this.emailId.sendKeys(emailId);
	}
	public String getPancard() {
		return pancard.getAttribute("value");
	}

	public void setPancard(String pancard) {
		this.pancard.sendKeys(pancard);
	}
	public String getAccountBalance() {
		return accountBalance.getAttribute("value");
	}

	public void setAccountBalance(String accountBalance) {
		this.accountBalance.clear();
		this.accountBalance.sendKeys(accountBalance);
	}
	public String getAccountType() {
		return accountType.getAttribute("value");
	}

	public void setAccountType(String accountType) {
		this.accountType.clear();
		this.accountType.sendKeys(accountType);
	}
	public String getSecurityQuestion() {
		return securityQuestion.getAttribute("value");
	}
	public void setSecurityQuestion(String securityQuestion) {
		//select.selectByValue(securityQuestion);
		this.securityQuestion.clear();
		this.securityQuestion.sendKeys(securityQuestion);
	}
	public String getSecretAnswer() {
		return secretAnswer.getAttribute("value");
	}

	public void setSecretAnswer(String secretAnswer) {
		this.secretAnswer.clear();
		this.secretAnswer.sendKeys(secretAnswer);
	}

	public void clickSubmit() {
		button.click();
	}
}
