package com.cg.banking.stepdefinition;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.banking.pagebeans.CustomerIdPage;
import com.cg.banking.pagebeans.IndexPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class DisplayCustomerDetailsStepDefinition {
	
	private WebDriver driver=new ChromeDriver();
	private IndexPage indexPage;
	private CustomerIdPage customerIdPage;
	
	@Given("^Customer is on 'Capgemini Banking System' Portal$")
	public void customer_is_on_Capgemini_Banking_System_Portal() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver.get("http://localhost:7898/home");
		String actualTitle=driver.getTitle();
		String expectedTitle="Capgemini";
		Assert.assertEquals(expectedTitle, actualTitle);
		indexPage=PageFactory.initElements(driver, IndexPage.class);
	}

	@When("^Customer clicks on 'view Customer Details' button$")
	public void customer_clicks_on_view_Customer_Details_button() throws Throwable {
		indexPage.clickCustomerDetailsButton();
	}

	@Then("^Customer is navigated to 'getCustomerIdPage'$")
	public void customer_is_navigated_to_getCustomerIdPage() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Customer Id";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@Given("^Customer is on 'getCustomerDetailsIdPage'$")
	public void customer_is_on_getCustomerDetailsIdPage() throws Throwable {
		driver.get("http://localhost:7898/customerDetails");
		String actualTitle=driver.getTitle();
		String expectedTitle="Customer Id";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@When("^Customer enters his Invalid 'CustomerId'$")
	public void customer_enters_his_Invalid_CustomerId() throws Throwable {
		customerIdPage=PageFactory.initElements(driver, CustomerIdPage.class);
		customerIdPage.setCustomerId("12");
		customerIdPage.clickSubmit();
	}

	@Then("^Displayed 'Error message' on 'getCustomerIdPage'$")
	public void displayed_Error_message_on_getCustomerIdPage() throws Throwable {
		String actualMessage=customerIdPage.getActualErrorMessage();
		String expectedMessage="Account Number is Not Found!!!!! Please Enter Right Account Number";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@When("^Customer enters his valid 'CustomerId'$")
	public void customer_enters_his_valid_CustomerId() throws Throwable {
		customerIdPage=PageFactory.initElements(driver, CustomerIdPage.class);
		customerIdPage.setCustomerId("1");
		customerIdPage.clickSubmit();
	}

	@Then("^Customer is navigated to 'displayCustomerDetailsPage' to display his Details$")
	public void customer_is_navigated_to_displayCustomerDetailsPage_to_display_his_Details() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Associate Details";
		Assert.assertEquals(expectedTitle, actualTitle);
	}
}
