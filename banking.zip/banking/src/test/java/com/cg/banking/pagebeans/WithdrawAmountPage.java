package com.cg.banking.pagebeans;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
public class WithdrawAmountPage {
	@FindBy(how=How.ID,id="accountNo")
	private WebElement accountNumber;
	
	@FindBy(how=How.ID,id="accountBalance")
	private WebElement accountBalance;

	
	@FindBy(how=How.NAME,name="submit")
	private WebElement button;
	
	@FindBy(how=How.CLASS_NAME,className="errorMessage")
	private WebElement actualMessage;
	
	public WithdrawAmountPage() {
		super();
	}

	public String getAccountNumber() {
		return accountNumber.getAttribute("value");
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber.clear();
		this.accountNumber.sendKeys(accountNumber);
	}

	public String getaccountBalance() {
		return accountBalance.getAttribute("value");
	}

	public void setAccountBalance(String accountBalance) {
		this.accountBalance.clear();
		this.accountBalance.sendKeys(accountBalance);
	}
	
	public String getActualMessage(){
		return actualMessage.getText();
	}
	
	public void clickSubmit() {
		button.click();
	}
}
