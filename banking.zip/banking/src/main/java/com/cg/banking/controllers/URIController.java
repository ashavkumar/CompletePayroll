package com.cg.banking.controllers;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
@Controller
public class URIController {
	Customer customer;
	Account account;
	Transaction transaction;
	@RequestMapping(value= {"/","/home","/indexPage"})
	public String getIndexPage() {
		return "indexPage";
	}
	@RequestMapping("/register")
	public String getRegisterPage() {
		return "registerPage";
	}
	@ModelAttribute
	public Customer getCustomer() {
		customer=new Customer();
		return customer;
	}
	@ModelAttribute
	public Account getAccount() {
		account=new Account();
		return account;
	}
	@RequestMapping("/fundTransfer")
	public String getAssociateIdPage() {
		return "getFundTransferDetailsPage";
	}
	@RequestMapping("/depositAmount")
	public String getDepositDetails() {
		return "getDepositAmountPage";
	}
	@RequestMapping("/withdrawAmount")
	public String getWithdrawDetails() {
		return "getWithdrawAmountPage";
	}
	@RequestMapping("/customerDetails")
	public String getCustomerId() {
		return "getCustomerIdPage";
	}
	@RequestMapping("/accountAllTransactions")
	public String getAccountNo() {
		return "getAccountNoPage";
	}
}