package com.cg.banking.services;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.beans.User;
import com.cg.banking.daoservices.BankingDAOAccount;
import com.cg.banking.daoservices.BankingDAOCustomer;
import com.cg.banking.daoservices.BankingDAOTransaction;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.AmountNotValidException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
@Component("bankingService")
public class BankingServiceImpl implements BankingService{
	@Autowired
	private BankingDAOAccount bankingDaoAccount;
	@Autowired
	private BankingDAOCustomer bankingDaoCustomer;
	@Autowired
	private BankingDAOTransaction bankingDaoTransaction;
	@Override
	public Customer openAccount(Customer customer,Account account) throws BankingServicesDownException{
		int  randomNumber=(int) ((Math.random()*((9999-1000)+1))+1000);
		String fixedString="Abcd";
		
		String loginPassword=fixedString+randomNumber;
		randomNumber=(int) ((Math.random()*((9999-1000)+1))+1000);
		String pinNumber=""+randomNumber;
		
		customer=new Customer(customer.getCustomerName(),customer.getEmailId(),customer.getAddress(),customer.getPancard(),new User(loginPassword,customer.getUser().getSecretQuestion(),pinNumber));

		account=new Account(account.getAccountType(),account.getAccountBalance(),customer);
		List<Account> listAccount=new ArrayList<Account>();
		listAccount.add(account);
		customer.setAccounts(listAccount);

		Transaction transaction=new Transaction(customer.getAccounts().get(0).getAccountBalance(),"credit",account);
		List<Transaction> listTransaction=new ArrayList<Transaction>();
		listTransaction.add(transaction);
		account.setTransaction(listTransaction);
		
		customer=bankingDaoCustomer.save(customer);
		return customer;
	}
	@Override
	public float depositAmount(long accountNo,int amount)
			throws AccountNotFoundException, BankingServicesDownException, AmountNotValidException
	{
		Account account=(Account) bankingDaoAccount.findById(accountNo).orElseThrow(()->new AccountNotFoundException());
		if(amount<=0)
			throw new AmountNotValidException();
		account.setAccountBalance(account.getAccountBalance()+amount);
		bankingDaoAccount.save(account);
		
		Transaction transaction=new Transaction();
		transaction.setAccount(account);
		transaction.setAmount(amount);
		transaction.setTransactionType("credit");
		bankingDaoTransaction.save(transaction);
		return account.getAccountBalance();
	}
	@Override
	public float withdrawAmount(long accountNo,int amount)
			throws AccountNotFoundException, BankingServicesDownException, InsufficientAmountException, AmountNotValidException
	{
		Account account=(Account) bankingDaoAccount.findById(accountNo).orElseThrow(()->new AccountNotFoundException());
		if(amount<=0)
			throw new AmountNotValidException();
		float balance=account.getAccountBalance();
		if(balance-amount<1000)
			throw new InsufficientAmountException();
		account.setAccountBalance(account.getAccountBalance()-amount);
		bankingDaoAccount.save(account);
		Transaction transaction=new Transaction();
		transaction.setAccount(account);
		transaction.setAmount(amount);
		transaction.setTransactionType("debit");
		bankingDaoTransaction.save(transaction);
		return account.getAccountBalance();
	}
	@Override
	public float fundTransfer(long accountNoTo, long accountNoFrom,
			int transferAmount)
					throws InsufficientAmountException, AccountNotFoundException,
					BankingServicesDownException,AmountNotValidException{
		//--- Withdraw From -------------
		Account accountFrom=(Account) bankingDaoAccount.findById(accountNoFrom).orElseThrow(()->new AccountNotFoundException());
		Account accountTo=(Account) bankingDaoAccount.findById(accountNoTo).orElseThrow(()->new AccountNotFoundException());
		if(transferAmount<=0)
			throw new AmountNotValidException();
		int balanceFrom=accountFrom.getAccountBalance();
		int balanceTo=accountTo.getAccountBalance();
		if(balanceFrom-transferAmount<1000){
			throw new InsufficientAmountException();
		}
		accountFrom.setAccountBalance(balanceFrom-transferAmount);
		bankingDaoAccount.save(accountFrom);
		Transaction transaction=new Transaction();
		transaction.setAccount(accountFrom);
		transaction.setAmount(transferAmount);
		transaction.setTransactionType("debit");
		bankingDaoTransaction.save(transaction);
		//--Deposit To--------------------------------
		//bankingDaoAccount.update(accountNoTo,accountTo.getAccountBalance()+transferAmount);
		accountTo.setAccountBalance(balanceTo+transferAmount);
		bankingDaoAccount.save(accountTo);
		transaction=new Transaction();
		transaction.setAccount(accountTo);
		transaction.setAmount(transferAmount);
		transaction.setTransactionType("credit");
		bankingDaoTransaction.save(transaction);
		return accountFrom.getAccountBalance();
	}
	@Override
	public Customer getCustomerDetails(long customerId)
			throws AccountNotFoundException, BankingServicesDownException {
		return bankingDaoCustomer.findById(customerId).orElseThrow(()->new AccountNotFoundException());
	}
	@Override
	public List<Transaction> getAccountAllTransaction(long accountNo)
			throws BankingServicesDownException, AccountNotFoundException {
		List<Transaction> transactionList=(List<Transaction>) bankingDaoTransaction.findAccountAllTransaction(accountNo);
		if(transactionList.isEmpty())
			throw new AccountNotFoundException();
		return transactionList;
	}
	@Override
	public List<Account> getAllAccountDetails()
			throws BankingServicesDownException {
		List<Account> accountList=bankingDaoAccount.findAll();
		return accountList;
	}
	@Override
	public List<Transaction> getAllTransactionDetails()
			throws BankingServicesDownException, AccountNotFoundException {
		List<Transaction> transactionList=bankingDaoTransaction.findAll();
		return transactionList;
	}
	@Override
	public List<Customer> getAllCustomerDetails()
			throws BankingServicesDownException, AccountNotFoundException {
		 List<Customer> customerList=bankingDaoCustomer.findAll();
		return customerList;
	}
}
