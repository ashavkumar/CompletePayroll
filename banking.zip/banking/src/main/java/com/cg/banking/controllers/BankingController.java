package com.cg.banking.controllers;
import java.util.List;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.AmountNotValidException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingService;
@Controller
public class BankingController {
	@Autowired
	private BankingService bankingService;
	Customer customer;
	Account account;
	Transaction transaction;
	@RequestMapping("/registerCustomer")
	public ModelAndView registerCustomerAction(@Valid@ModelAttribute Customer customer,BindingResult bindingResultCustomer,@RequestParam("accounts[0].accountBalance") int accountBalance,@RequestParam("accounts[0].accountType") String accountType) {
		if(bindingResultCustomer.hasErrors())
			return new ModelAndView("registerPage");
		account=new Account();
		account.setAccountBalance(accountBalance);
		account.setAccountType(accountType);
		try {
			customer=bankingService.openAccount(customer,account);
		} catch (BankingServicesDownException e) {
			return new ModelAndView("registerPage","errorMessage","Error Occurred!!!!! Please Try Again");
		}
		
		return new ModelAndView("registrationSuccessPage", "customer", customer);
	}
	@RequestMapping("/Deposit")
	public ModelAndView depositAction(@Valid@ModelAttribute Account account ,BindingResult bindingResultAccount){
		float updatedBalance=0;
		try {
			updatedBalance = bankingService.depositAmount(account.getAccountNo(), account.getAccountBalance());
		} catch (AccountNotFoundException e) {
			return new ModelAndView("getDepositAmountPage","errorMessage","Account Number is Not Found!!!!! Please Enter Right Account Number");
		} catch (BankingServicesDownException e) {
			return new ModelAndView("getDepositAmountPage","errorMessage","Error Occurred!!!!! Please Try Again");
		} catch (AmountNotValidException e) {
			return new ModelAndView("getDepositAmountPage","errorMessage","Amount is Not Valid!!!!! Please Enter Valid Amount");
		}
		String message="Transaction Successful. Updated Balance is:"+updatedBalance;
		return new ModelAndView("indexPage", "message", message);
	}
	@RequestMapping("/Withdraw")
	public ModelAndView withdrawAction(@Valid@ModelAttribute Account account ,BindingResult bindingResultAccount) {
		float updatedBalance=0;
		try {
			updatedBalance = bankingService.withdrawAmount(account.getAccountNo(), account.getAccountBalance());
		} catch (InsufficientAmountException e) {
			return new ModelAndView("getWithdrawAmountPage","errorMessage","Insufficient Amount!!!Please Make another Transaction.");
		} catch (AccountNotFoundException e) {
			return new ModelAndView("getWithdrawAmountPage","errorMessage","Account Number is Not Found!!!!! Please Enter Right Account Number");
		} catch (InvalidPinNumberException e) {
			return new ModelAndView("getWithdrawAmountPage","errorMessage","Pin Number is Wrong!!!!! 2 More Chance Left.....");
		} catch (BankingServicesDownException e) {
			return new ModelAndView("getWithdrawAmountPage","errorMessage","Error Occurred!!!!! Please Try Again");
		} catch (AccountBlockedException e) {
			return new ModelAndView("getWithdrawAmountPage","errorMessage","Your Account has been Blocked!!!So Contact Near by Branch of Our Bank");
		} catch (AmountNotValidException e) {
			return new ModelAndView("getWithdrawAmountPage","errorMessage","Amount is Not Valid!!!!! Please Enter Valid Amount");
		}
		String message="Transaction Successful. Updated Balance is:"+updatedBalance;
		return new ModelAndView("indexPage", "message", message);
	}
	@RequestMapping("/FundTransfer")
	public ModelAndView fundTransferAction(@RequestParam("accountNoFrom") long accountNoFrom,@RequestParam("accountNoTo") long accountNoTo,@RequestParam("transferAmount") int transferAmount){
		float updatedBalance=0;
		try {
			updatedBalance = bankingService.fundTransfer(accountNoTo, accountNoFrom, transferAmount);
		} catch (InsufficientAmountException e) {
			return new ModelAndView("getFundTransferDetailsPage","errorMessage","Insufficient Amount!!!Please Make another Transaction.");
		} catch (AccountNotFoundException e) {
			return new ModelAndView("getFundTransferDetailsPage","errorMessage","Account Number is Not Found!!!!! Please Enter Right Account Number");
		} catch (InvalidPinNumberException e) {
			return new ModelAndView("getFundTransferDetailsPage","errorMessage","Pin Number is Wrong!!!!! 2 More Chance Left.....");
		} catch (BankingServicesDownException e) {
			return new ModelAndView("getFundTransferDetailsPage","errorMessage","Error Occurred!!!!! Please Try Again");
		} catch (AccountBlockedException e) {
			return new ModelAndView("getFundTransferDetailsPage","errorMessage","Your Account has been Blocked!!!So Contact Near by Branch of Our Bank");
		} catch (AmountNotValidException e) {
			return new ModelAndView("getFundTransferDetailsPage","errorMessage","Amount is Not Valid!!!!! Please Enter Valid Amount");
		}
		String message="Transaction Successful. Updated Balance is:"+updatedBalance;
		return new ModelAndView("indexPage", "message", message);
	}
	@RequestMapping("/displayCustomer")
	public ModelAndView displayCustomerDeatils(@RequestParam("customerId")int customerId){
		try {
			customer=bankingService.getCustomerDetails(customerId);
		} catch (AccountNotFoundException e) {
			return new ModelAndView("getCustomerIdPage","errorMessage","Account Number is Not Found!!!!! Please Enter Right Account Number");
		} catch (BankingServicesDownException e) {
			return new ModelAndView("getCustomerIdPage","errorMessage","Error Occurred!!!!! Please Try Again");
		}
		return new ModelAndView("displayCustomerDetailsPage", "customer" , customer);
	}
	@RequestMapping("/displayAccountAllTransactions")
	public ModelAndView displayAccountAllTransactions(@RequestParam("accountNo")int accountNo) {
		List<Transaction> listTransaction;
		try {
			listTransaction = bankingService.getAccountAllTransaction(accountNo);
		} catch (BankingServicesDownException e) {
			return new ModelAndView("getAccountNoPage","errorMessage","Error Occurred!!!!! Please Try Again");
		} catch (AccountNotFoundException e) {
			return new ModelAndView("getAccountNoPage","errorMessage","Account Number is Not Found!!!!! Please Enter Right Account Number");
		}
		return new ModelAndView("displayAccountAllTransactionsPage", "listTransaction", listTransaction);
	}
	@RequestMapping("/allAccountDetails")
	public ModelAndView getAllAccountDeatils() throws BankingServicesDownException{
		List<Account> accounts=bankingService.getAllAccountDetails();
		return new ModelAndView("displayAllAccountDetailsPage", "accounts", accounts);
	}
	@RequestMapping("/allCustomerDetails")
	public ModelAndView getAllCustomerDeatils() throws BankingServicesDownException, AccountNotFoundException{
		List<Customer> customers=bankingService.getAllCustomerDetails();
		return new ModelAndView("displayAllCustomerDetailsPage", "customers", customers);
	}
	@RequestMapping("/allTransactionDetails")
	public ModelAndView getAllTransactionDetails() throws BankingServicesDownException, AccountNotFoundException{
		List<Transaction> transactions=bankingService.getAllTransactionDetails();
		return new ModelAndView("displayAllTransactionDetailsPage", "transactions",transactions);
	}
}