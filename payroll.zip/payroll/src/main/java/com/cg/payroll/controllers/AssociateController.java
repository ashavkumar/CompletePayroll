package com.cg.payroll.controllers;
import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateNotFoundException;
import com.cg.payroll.exceptions.CustomersNotExistException;
import com.cg.payroll.exceptions.PayrollServiceDownException;
import com.cg.payroll.services.PayrollServices;
@Controller
public class AssociateController {
	@Autowired
	private PayrollServices payrollServices;
	Associate associate;
	@RequestMapping("/registerAssociate")
	public ModelAndView registerAssociateAction(@Valid@ModelAttribute Associate associate,BindingResult bindingResult) {
		if(bindingResult.hasErrors())
			return new ModelAndView("registerPage");
		try {
			associate=payrollServices.acceptAssociateDetails(associate);
		} catch (PayrollServiceDownException e) {
			return new ModelAndView("registerPage","errorMessage","Error Occured!!!!Please Try Again");
		}
		return new ModelAndView("registrationSuccessPage", "associate", associate);
	}
	@RequestMapping("/CalculateNetSalary")
	public ModelAndView calculateNetSalary(@RequestParam("associateId") int associateId){
		int netSalary;
		try {
			netSalary = payrollServices.calculateNetSalary(associateId);
		} catch (AssociateNotFoundException e) {
			return new ModelAndView("associateIdPageNetSalary","errorMessage","Customer Not Found!!!!Please Try Again");
		} catch (PayrollServiceDownException e) {
			return new ModelAndView("associateIdPageNetSalary","errorMessage","Error Occured!!!!Please Try Again");
		}
		return new ModelAndView("displayNetSalaryPage", "netSalary", netSalary);
	}
	@RequestMapping("/AssociateDetails")
	public ModelAndView getAssociateDeatils(@RequestParam("associateId")int associateId){
		try {
			associate=payrollServices.getAssociateDetails(associateId);
		} catch (AssociateNotFoundException e) {
			return new ModelAndView("associateIdPageAssociateDetails","errorMessage","Customer Not Found!!!!Please Try Again");
		} catch (PayrollServiceDownException e) {
			return new ModelAndView("associateIdPageAssociateDetails","errorMessage","Error Occured!!!!Please Try Again");
		}
		return new ModelAndView("displayAssociateDetailsPage", "associate", associate);
	}
	@RequestMapping("/AllAssociateDetails")
	public ModelAndView getAllAssociateDeatils(){
		ArrayList<Associate> associates=null;
		try {
			associates = payrollServices.getAllAsociateDetails();
		} catch (CustomersNotExistException e) {
			return new ModelAndView("indexPage","errorMessage","No Customer Exist!!!!!!!");
		} catch (PayrollServiceDownException e) {
			return new ModelAndView("indexPage","errorMessage","Error Occured!!!!Please Try Again");
		}
		return new ModelAndView("displayAllAssociateDetailsPage", "associates", associates);
	}
}