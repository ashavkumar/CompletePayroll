package com.cg.payroll.stepdefinition;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.payroll.pagebeans.IndexPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class DisplayAllAssociateDetailsStepDefinition {
	private WebDriver  driver=new ChromeDriver();
	private IndexPage indexPage;
	@Given("^Admin is on the  'Capgemini Payroll System' Portal$")
	public void admin_is_on_the_Capgemini_Payroll_System_Portal() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver.get("http://localhost:8888/home");
		String actualTitle=driver.getTitle();
		String expectedTitle="Capgemini";
		Assert.assertEquals(expectedTitle, actualTitle);
		indexPage=PageFactory.initElements(driver, IndexPage.class);
	}

	@When("^Admin clicks on 'View All Associate Details' button$")
	public void admin_clicks_on_View_All_Associate_Details_button() throws Throwable {
		indexPage.clickAllAssociateDetailsButton();
	}

	@Then("^Error Message Displayed on the indexPage$")
	public void error_Message_Displayed_on_the_indexPage() throws Throwable {
		String actualMessage=indexPage.getActualErrorMessage();
		String expectedMessage="No Customer Exist!!!!!!!";
		Assert.assertEquals(expectedMessage, actualMessage);
	}

	@Then("^Admin navigated to 'displayAllAssociatePage' to display Associate Details$")
	public void admin_navigated_to_displayAllAssociatePage_to_display_Associate_Details() throws Throwable {
		//driver.get("http://localhost:8888/AllAssociateDetails");
		String actualMessage=driver.getTitle();
		String expectedMessage="All Associate Details";
		Assert.assertEquals(expectedMessage, actualMessage);
	}
}
