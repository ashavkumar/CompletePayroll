package com.cg.payroll.stepdefinition;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.payroll.pagebeans.DisplayAssociateDetailsIdPage;
import com.cg.payroll.pagebeans.IndexPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class DisplayAssociateDetailsStepDefinition {
	private WebDriver driver=new ChromeDriver();
	private IndexPage indexPage;
	private DisplayAssociateDetailsIdPage displayAssociateDetailsIdPage;
	@Given("^Associate is on 'Capgemini Payroll System' Portal$")
	public void associate_is_on_Capgemini_Payroll_System_Portal() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver.get("http://localhost:8888/home");
		String actualTitle=driver.getTitle();
		String expectedTitle="Capgemini";
		Assert.assertEquals(expectedTitle, actualTitle);
		indexPage=PageFactory.initElements(driver, IndexPage.class);
	}

	@When("^Associate clicks on 'view Associate Details' button$")
	public void associate_clicks_on_view_Associate_Details_button() throws Throwable {
		indexPage.clickgetAssociateDetailsButton();
	}

	@Then("^Associate is navigated to 'getAssociateDetailsIdPage'$")
	public void associate_is_navigated_to_getAssociateDetailsIdPage() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Associate Id";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@Given("^Associate is on 'getAssociateDetailsIdPage'$")
	public void associate_is_on_getAssociateDetailsIdPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver.get("http://localhost:8888/getAssociateDetails");
		String actualTitle=driver.getTitle();
		String expectedTitle="Associate Id";
		Assert.assertEquals(expectedTitle, actualTitle);
		indexPage=PageFactory.initElements(driver, IndexPage.class);
	}

	@When("^Associate enters his Invalid 'associateId'$")
	public void associate_enters_his_Invalid_associateId() throws Throwable {
		displayAssociateDetailsIdPage=PageFactory.initElements(driver, DisplayAssociateDetailsIdPage.class);
		displayAssociateDetailsIdPage.setAssociateId("12345");
		displayAssociateDetailsIdPage.clickSubmit();
	}

	@Then("^Displayed 'Error message' on 'getAssociateDetailsIdPage'$")
	public void displayed_Error_message_on_getAssociateDetailsIdPage() throws Throwable {
		String actualErrorMessage=displayAssociateDetailsIdPage.getActualErrorMessage();
		String expectedErrorMessage="Customer Not Found!!!!Please Try Again";
		Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
	}

	@When("^Associate enters his valid 'associateId'$")
	public void associate_enters_his_valid_associateId() throws Throwable {
		displayAssociateDetailsIdPage=PageFactory.initElements(driver, DisplayAssociateDetailsIdPage.class);
		displayAssociateDetailsIdPage.setAssociateId("1");
		displayAssociateDetailsIdPage.clickSubmit();
	}

	@Then("^Associate is navigated to 'displayAssociateDetailsIdPage' to display his Details$")
	public void associate_is_navigated_to_displayAssociateDetailsIdPage_to_display_his_Details() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="associate Details";
		Assert.assertEquals(expectedTitle, actualTitle);
	}
}
