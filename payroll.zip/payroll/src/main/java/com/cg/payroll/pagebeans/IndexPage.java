package com.cg.payroll.pagebeans;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
public class IndexPage {
	@FindBy(how=How.NAME,name="register")
	private WebElement registerButton;
	
	@FindBy(how=How.NAME,name="calculateNetSalary")
	private WebElement calculateNetSalaryButton;
	
	@FindBy(how=How.NAME,name="getAssociateDetails")
	private WebElement getAssociateDetailsButton;
	
	@FindBy(how=How.NAME,name="AllAssociateDetails")
	private WebElement AllAssociateDetailsButton;

	@FindBy(how=How.CLASS_NAME,className="errorMessage")
	private WebElement actualErrorMessage;
	
	public IndexPage() {
		super();
	}
	
	
	public void clickregisterButton() {
		registerButton.click();
	}
	public void clickcalculateNetSalaryButton() {
		calculateNetSalaryButton.click();
	}
	public void clickgetAssociateDetailsButton() {
		getAssociateDetailsButton.click();
	}
	public void clickAllAssociateDetailsButton() {
		AllAssociateDetailsButton.click();
	}	
	public String getActualErrorMessage(){
		return actualErrorMessage.getText();
	}

}
