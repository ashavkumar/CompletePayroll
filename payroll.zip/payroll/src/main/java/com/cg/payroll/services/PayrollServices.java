package com.cg.payroll.services;
import java.util.ArrayList;

import com.cg.payroll.beans.*;
import com.cg.payroll.exceptions.AssociateNotFoundException;
import com.cg.payroll.exceptions.CustomersNotExistException;
import com.cg.payroll.exceptions.PayrollServiceDownException;
public interface PayrollServices {
	Associate acceptAssociateDetails(Associate associate) throws PayrollServiceDownException;
	int calculateNetSalary(int associateId) throws AssociateNotFoundException, PayrollServiceDownException;
	Associate getAssociateDetails(int associateId) throws AssociateNotFoundException, PayrollServiceDownException;
	ArrayList<Associate>getAllAsociateDetails() throws CustomersNotExistException, PayrollServiceDownException;
}