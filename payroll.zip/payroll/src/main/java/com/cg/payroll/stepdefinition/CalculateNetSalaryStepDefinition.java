package com.cg.payroll.stepdefinition;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.payroll.pagebeans.CalculateNetSalaryIdPage;
import com.cg.payroll.pagebeans.IndexPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class CalculateNetSalaryStepDefinition {
	private WebDriver driver=new ChromeDriver();
	private IndexPage indexPage;
	private CalculateNetSalaryIdPage calculateNetSalaryIdPage;
	@Given("^Associate is on the 'Capgemini Payroll System' Portal$")
	public void associate_is_on_the_Capgemini_Payroll_System_Portal() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver.get("http://localhost:8888/home");
		String actualTitle=driver.getTitle();
		String expectedTitle="Capgemini";
		Assert.assertEquals(expectedTitle, actualTitle);
		indexPage=PageFactory.initElements(driver, IndexPage.class);
	}

	@When("^Associate clicks on 'Calculate Net Salary' button$")
	public void associate_clicks_on_Calculate_Net_Salary_button() throws Throwable {
		indexPage.clickcalculateNetSalaryButton();
	}

	@Then("^Associate is navigated to 'calculateNetSalaryPage'$")
	public void associate_is_navigated_to_calculateNetSalaryPage() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Associate Id";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@Given("^Associate is on 'calculateNetSalaryPage'$")
	public void associate_is_on_calculateNetSalaryPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver.get("http://localhost:8888/calculateNetSalary");
		String actualTitle=driver.getTitle();
		String expectedTitle="Associate Id";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@When("^Associate enters Invalid 'associateId'$")
	public void associate_enters_Invalid_associateId() throws Throwable {
		calculateNetSalaryIdPage=PageFactory.initElements(driver, CalculateNetSalaryIdPage.class);
		calculateNetSalaryIdPage.setAssociateId("12345");
		calculateNetSalaryIdPage.clickSubmit();
	}

	@Then("^Displayed 'Error message' on 'calculateNetSalaryPage'$")
	public void displayed_Error_message_on_calculateNetSalaryPage() throws Throwable {
		String actualErrorMessage=calculateNetSalaryIdPage.getActualErrorMessage();
		String expectedErrorMessage="Customer Not Found!!!!Please Try Again";
		Assert.assertEquals(expectedErrorMessage, actualErrorMessage);
	}

	@When("^Associate enters valid 'associateId'$")
	public void associate_enters_valid_associateId() throws Throwable {
		calculateNetSalaryIdPage=PageFactory.initElements(driver, CalculateNetSalaryIdPage.class);
		calculateNetSalaryIdPage.setAssociateId("1");
		calculateNetSalaryIdPage.clickSubmit();
	}

	@Then("^Associate is navigated to 'displayNetSalaryPage' to display NetSalary$")
	public void associate_is_navigated_to_displayNetSalaryPage_to_display_NetSalary() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Net Salary";
		Assert.assertEquals(expectedTitle, actualTitle);
	}
}
