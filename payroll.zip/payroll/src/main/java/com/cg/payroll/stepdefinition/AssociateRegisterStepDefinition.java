package com.cg.payroll.stepdefinition;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.payroll.pagebeans.IndexPage;
import com.cg.payroll.pagebeans.RegisterPage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class AssociateRegisterStepDefinition {
	private WebDriver driver=new ChromeDriver();
	private IndexPage indexPage;
	private RegisterPage registerPage;
	@Given("^User is on the Capgemini Payroll Portal 'indexPage'$")
	public void user_is_on_the_Capgemini_Payroll_Portal_indexPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver.get("http://localhost:8888/home");
		String actualTitle=driver.getTitle();
		String expectedTitle="Capgemini";
		Assert.assertEquals(expectedTitle, actualTitle);
		indexPage=PageFactory.initElements(driver, IndexPage.class);
	}

	@When("^User clicks on 'Register' button$")
	public void user_clicks_on_Register_button() throws Throwable {
		indexPage.clickregisterButton();
	}

	@Then("^User is navigated to 'registerPage'$")
	public void user_is_navigated_to_registerPage() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Registration";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@Given("^User is on the 'registerPage'$")
	public void user_is_on_the_registerPage() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver.get("http://localhost:8888/register");
		String actualTitle=driver.getTitle();
		String expectedTitle="Registration";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@When("^User enters Invalid Registration details$")
	public void user_enters_Invalid_Registration_details() throws Throwable {
		registerPage=PageFactory.initElements(driver, RegisterPage.class);
		registerPage.setYearlyInvestmentUnder80c("15000");
		registerPage.setFirstName("Ashav");
		registerPage.setLastName("Kumar");
		registerPage.setDepartment("IT");
		registerPage.setDesignation("Analyst");
		registerPage.setEmailId("ashav21011996gmail.com");
		registerPage.setPancard("HHTPK0434B");
		registerPage.setAccountNumber("202422515");
		registerPage.setBankName("SBI");
		registerPage.setIfscCode("SBIN0001882");
		registerPage.setBasicSalary("17000");
		registerPage.clickSubmit();
	}

	@Then("^Displayed 'Registration Error message' on 'registerPage'$")
	public void displayed_Registration_Error_message_on_registerPage() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Registration";
		Assert.assertEquals(expectedTitle, actualTitle);
	}

	@When("^User enters valid set of Registration details$")
	public void user_enters_valid_set_of_Registration_details() throws Throwable {
		registerPage=PageFactory.initElements(driver, RegisterPage.class);
		registerPage.setYearlyInvestmentUnder80c("15000");
		registerPage.setFirstName("Ashav");
		registerPage.setLastName("Kumar");
		registerPage.setDepartment("IT");
		registerPage.setDesignation("Analyst");
		registerPage.setEmailId("ashav21011996@gmail.com");
		registerPage.setPancard("HHTPK0434B");
		registerPage.setAccountNumber("202422515");
		registerPage.setBankName("SBI");
		registerPage.setIfscCode("SBIN0001882");
		registerPage.setBasicSalary("17000");
		registerPage.clickSubmit();
	}

	@Then("^User navigated to 'registrationSuccessPage'$")
	public void user_navigated_to_registrationSuccessPage() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Registration Success";
		Assert.assertEquals(expectedTitle, actualTitle);
	}
}
